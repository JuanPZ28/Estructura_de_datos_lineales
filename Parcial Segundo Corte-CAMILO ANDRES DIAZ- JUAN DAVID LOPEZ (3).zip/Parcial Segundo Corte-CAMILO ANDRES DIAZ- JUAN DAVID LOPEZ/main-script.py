"""
Script principal para demostrar el uso de las estructuras de datos
y algoritmos implementados para el parcial segundo corte.
"""

from estructuras_datos_y_algoritmos import (
    CircularList, Stack, Queue, PriorityQueue, Deque, CircularQueue,
    merge_sort, quick_sort, linear_search, binary_search, BinarySearchTree
)

def main():
    """Función principal para demostrar los TDAs y algoritmos."""
    
    # Leer la lista de enteros desde el input
    try:
        input_str = input("Ingrese una lista de enteros separados por comas (por ejemplo, 5,3,8,1,9,2): ")
        data = []
        for x in input_str.split(","):
            try:
                data.append(int(x.strip()))
            except ValueError:
                print(f"Advertencia: '{x.strip()}' no es un entero válido y será ignorado.")
        
        if not data:
            print("No se ingresaron enteros válidos. Usando lista de ejemplo: [5, 3, 8, 1, 9, 2]")
            data = [5, 3, 8, 1, 9, 2]
    except Exception as e:
        print(f"Error al leer la entrada: {e}")
        print("Usando lista de ejemplo: [5, 3, 8, 1, 9, 2]")
        data = [5, 3, 8, 1, 9, 2]
    
    print("\n" + "="*50)
    print("DATOS ORIGINALES:", data)
    print("="*50)
    
    print("\n--- CIRCULAR LIST ---")
    try:
        # Crear una lista circular con capacidad suficiente
        cl = CircularList(len(data))
        print(f"Lista circular creada con capacidad {len(data)}")
        
        # Insertar los valores
        for val in data:
            cl.insert(val)
            print(f"Insertado: {val}")
        
        print(f"Tamaño de la lista circular: {len(cl)}")
        
        # Eliminar algunos valores
        print(f"Eliminado: {cl.delete()}")
        print(f"Eliminado: {cl.delete()}")
        print(f"Tamaño actualizado: {len(cl)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- STACK (PILA) ---")
    try:
        # Crear una pila
        stack = Stack()
        print("Pila creada")
        
        # Apilar los primeros 3 valores
        for i in range(min(3, len(data))):
            stack.push(data[i])
            print(f"Apilado: {data[i]}")
        
        print(f"Tamaño de la pila: {len(stack)}")
        
        # Desapilar 2 valores
        print(f"Desapilado: {stack.pop()}")
        print(f"Desapilado: {stack.pop()}")
        print(f"Tamaño actualizado: {len(stack)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- QUEUE (COLA) ---")
    try:
        # Crear una cola
        queue = Queue()
        print("Cola creada")
        
        # Encolar todos los valores
        for val in data:
            queue.enqueue(val)
            print(f"Encolado: {val}")
        
        print(f"Tamaño de la cola: {len(queue)}")
        
        # Desencolar 2 valores
        print(f"Desencolado: {queue.dequeue()}")
        print(f"Desencolado: {queue.dequeue()}")
        print(f"Tamaño actualizado: {len(queue)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- PRIORITY QUEUE (COLA DE PRIORIDAD) ---")
    try:
        # Crear una cola de prioridad
        pq = PriorityQueue()
        print("Cola de prioridad creada")
        
        # Encolar todos los valores
        for val in data:
            pq.enqueue(val)
            print(f"Encolado con prioridad: {val}")
        
        print(f"Tamaño de la cola de prioridad: {len(pq)}")
        
        # Desencolar 2 valores (saldrán en orden de prioridad)
        print(f"Desencolado (mayor prioridad): {pq.dequeue()}")
        print(f"Desencolado (mayor prioridad): {pq.dequeue()}")
        print(f"Tamaño actualizado: {len(pq)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- DEQUE (BICOLA) ---")
    try:
        # Crear una bicola
        deque = Deque()
        print("Bicola creada")
        
        # Agregar valores alternando front y rear
        for i, val in enumerate(data):
            if i % 2 == 0:
                deque.add_front(val)
                print(f"Agregado al frente: {val}")
            else:
                deque.add_rear(val)
                print(f"Agregado al final: {val}")
        
        print(f"Tamaño de la bicola: {len(deque)}")
        
        # Eliminar un valor del frente y otro del final
        print(f"Eliminado del frente: {deque.remove_front()}")
        print(f"Eliminado del final: {deque.remove_rear()}")
        print(f"Tamaño actualizado: {len(deque)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- CIRCULAR QUEUE (COLA CIRCULAR) ---")
    try:
        # Crear una cola circular con capacidad suficiente
        cq = CircularQueue(len(data))
        print(f"Cola circular creada con capacidad {len(data)}")
        
        # Encolar todos los valores
        for val in data:
            cq.enqueue(val)
            print(f"Encolado: {val}")
        
        print(f"Tamaño de la cola circular: {len(cq)}")
        
        # Desencolar 2 valores
        print(f"Desencolado: {cq.dequeue()}")
        print(f"Desencolado: {cq.dequeue()}")
        print(f"Tamaño actualizado: {len(cq)}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n--- ALGORITMOS DE ORDENAMIENTO ---")
    # Merge Sort
    sorted_merge = merge_sort(data.copy())
    print(f"Merge Sort: {sorted_merge}")
    
    # Quick Sort
    sorted_quick = quick_sort(data.copy())
    print(f"Quick Sort: {sorted_quick}")
    
    print("\n--- ALGORITMOS DE BÚSQUEDA ---")
    # Pedir un valor a buscar con validación
    target = None
    while target is None:
        try:
            target_input = input("Ingrese un valor entero a buscar: ")
            target = int(target_input)
        except ValueError:
            print(f"Error: '{target_input}' no es un entero válido. Por favor, ingrese un número entero.")
    
    # Búsqueda Lineal
    linear_result = linear_search(data, target)
    if linear_result != -1:
        print(f"Búsqueda Lineal: El valor {target} fue encontrado en el índice {linear_result}")
    else:
        print(f"Búsqueda Lineal: El valor {target} no fue encontrado en la lista")
    
    # Búsqueda Binaria (en la lista ordenada)
    binary_result = binary_search(sorted_merge, target)
    if binary_result != -1:
        print(f"Búsqueda Binaria: El valor {target} fue encontrado en el índice {binary_result} (en la lista ordenada)")
    else:
        print(f"Búsqueda Binaria: El valor {target} no fue encontrado en la lista ordenada")
    
    print("\n--- ÁRBOL BINARIO DE BÚSQUEDA ---")
    # Crear un BST
    bst = BinarySearchTree()
    print("Árbol Binario de Búsqueda creado")
    
    # Insertar todos los valores
    for val in data:
        bst.insert(val)
        print(f"Insertado en BST: {val}")
    
    # Recorrido in-order
    print(f"Recorrido In-Order (valores ordenados): {bst.in_order_traversal()}")
    
    # Altura del árbol
    print(f"Altura del árbol: {bst.height()}")
    
    # Buscar el valor target en el BST
    if bst.find(target):
        print(f"El valor {target} se encuentra en el BST")
    else:
        print(f"El valor {target} no se encuentra en el BST")


if __name__ == "__main__":
    main()