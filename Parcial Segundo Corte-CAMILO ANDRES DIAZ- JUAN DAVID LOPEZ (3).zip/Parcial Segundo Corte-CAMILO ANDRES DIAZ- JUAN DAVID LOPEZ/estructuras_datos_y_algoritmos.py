"""
Implementación de Estructuras de Datos Lineales y Algoritmos
para el parcial segundo corte.

Incluye:
- Lista Circular
- Pila (Stack)
- Cola (Queue, PriorityQueue, Deque, CircularQueue)
- Algoritmos de Ordenamiento (merge_sort, quick_sort)
- Algoritmos de Búsqueda (linear_search, binary_search)
- Árbol Binario de Búsqueda (BST)
"""

import heapq

#----- PARTE 1: LISTA CIRCULAR Y PILA -----#

class CircularList:
    """
    Implementación de una Lista Circular con capacidad fija.
    
    Attributes:
        capacity (int): Capacidad máxima de la lista
        data (list): Arreglo para almacenar los elementos
        size (int): Número actual de elementos en la lista
        front (int): Índice del elemento frontal
        rear (int): Índice del último elemento
    """
    
    def __init__(self, capacity):
        """
        Constructor para la lista circular.
        
        Args:
            capacity (int): Capacidad máxima de la lista
        """
        self.capacity = capacity
        self.data = [None] * capacity
        self.size = 0
        self.front = 0
        self.rear = -1
        
    def insert(self, value):
        """
        Inserta un elemento al final de la lista.
        
        Args:
            value: Elemento a insertar
            
        Raises:
            Exception: Si la lista está llena
        """
        if self.is_full():
            raise Exception("La lista circular está llena")
        
        self.rear = (self.rear + 1) % self.capacity
        self.data[self.rear] = value
        self.size += 1
        
    def delete(self):
        """
        Elimina y devuelve el elemento al frente de la lista.
        
        Returns:
            El elemento eliminado
            
        Raises:
            Exception: Si la lista está vacía
        """
        if self.is_empty():
            raise Exception("La lista circular está vacía")
        
        value = self.data[self.front]
        self.data[self.front] = None
        self.front = (self.front + 1) % self.capacity
        self.size -= 1
        return value
    
    def is_empty(self):
        """
        Verifica si la lista está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return self.size == 0
    
    def is_full(self):
        """
        Verifica si la lista está llena.
        
        Returns:
            bool: True si está llena, False en caso contrario
        """
        return self.size == self.capacity
    
    def __len__(self):
        """
        Devuelve el número de elementos en la lista.
        
        Returns:
            int: Cantidad de elementos
        """
        return self.size


class Stack:
    """
    Implementación de una Pila (LIFO) usando una lista de Python.
    
    Attributes:
        items (list): Lista interna para almacenar los elementos
    """
    
    def __init__(self):
        """Constructor para la pila."""
        self.items = []
        
    def push(self, value):
        """
        Agrega un elemento al tope de la pila.
        
        Args:
            value: Elemento a agregar
        """
        self.items.append(value)
        
    def pop(self):
        """
        Elimina y devuelve el elemento del tope de la pila.
        
        Returns:
            El elemento en el tope
            
        Raises:
            Exception: Si la pila está vacía
        """
        if self.is_empty():
            raise Exception("La pila está vacía")
        return self.items.pop()
    
    def peek(self):
        """
        Devuelve el elemento del tope sin eliminarlo.
        
        Returns:
            El elemento en el tope
            
        Raises:
            Exception: Si la pila está vacía
        """
        if self.is_empty():
            raise Exception("La pila está vacía")
        return self.items[-1]
    
    def is_empty(self):
        """
        Verifica si la pila está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return len(self.items) == 0
    
    def __len__(self):
        """
        Devuelve el número de elementos en la pila.
        
        Returns:
            int: Cantidad de elementos
        """
        return len(self.items)


#----- PARTE 2: COLA Y VARIANTES -----#

class Queue:
    """
    Implementación de una Cola (FIFO).
    
    Attributes:
        items (list): Lista interna para almacenar los elementos
    """
    
    def __init__(self):
        """Constructor para la cola."""
        self.items = []
        
    def enqueue(self, value):
        """
        Agrega un elemento al final de la cola.
        
        Args:
            value: Elemento a agregar
        """
        self.items.append(value)
        
    def dequeue(self):
        """
        Elimina y devuelve el elemento al frente de la cola.
        
        Returns:
            El elemento al frente
            
        Raises:
            Exception: Si la cola está vacía
        """
        if self.is_empty():
            raise Exception("La cola está vacía")
        return self.items.pop(0)
    
    def is_empty(self):
        """
        Verifica si la cola está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return len(self.items) == 0
    
    def __len__(self):
        """
        Devuelve el número de elementos en la cola.
        
        Returns:
            int: Cantidad de elementos
        """
        return len(self.items)


class PriorityQueue:
    """
    Implementación de una Cola de Prioridad usando heapq.
    Menor número = mayor prioridad.
    
    Attributes:
        items (list): Lista interna que funcionará como heap
    """
    
    def __init__(self):
        """Constructor para la cola de prioridad."""
        self.items = []
        
    def enqueue(self, value):
        """
        Agrega un elemento a la cola con prioridad.
        
        Args:
            value: Elemento a agregar (debe ser comparable)
        """
        heapq.heappush(self.items, value)
        
    def dequeue(self):
        """
        Elimina y devuelve el elemento con mayor prioridad.
        
        Returns:
            El elemento con mayor prioridad
            
        Raises:
            Exception: Si la cola está vacía
        """
        if self.is_empty():
            raise Exception("La cola de prioridad está vacía")
        return heapq.heappop(self.items)
    
    def is_empty(self):
        """
        Verifica si la cola está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return len(self.items) == 0
    
    def __len__(self):
        """
        Devuelve el número de elementos en la cola.
        
        Returns:
            int: Cantidad de elementos
        """
        return len(self.items)


class Deque:
    """
    Implementación de una Bicola (Deque).
    
    Attributes:
        items (list): Lista interna para almacenar los elementos
    """
    
    def __init__(self):
        """Constructor para la bicola."""
        self.items = []
        
    def add_front(self, value):
        """
        Agrega un elemento al frente de la bicola.
        
        Args:
            value: Elemento a agregar
        """
        self.items.insert(0, value)
        
    def add_rear(self, value):
        """
        Agrega un elemento al final de la bicola.
        
        Args:
            value: Elemento a agregar
        """
        self.items.append(value)
        
    def remove_front(self):
        """
        Elimina y devuelve el elemento al frente de la bicola.
        
        Returns:
            El elemento al frente
            
        Raises:
            Exception: Si la bicola está vacía
        """
        if self.is_empty():
            raise Exception("La bicola está vacía")
        return self.items.pop(0)
    
    def remove_rear(self):
        """
        Elimina y devuelve el elemento al final de la bicola.
        
        Returns:
            El elemento al final
            
        Raises:
            Exception: Si la bicola está vacía
        """
        if self.is_empty():
            raise Exception("La bicola está vacía")
        return self.items.pop()
    
    def is_empty(self):
        """
        Verifica si la bicola está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return len(self.items) == 0
    
    def __len__(self):
        """
        Devuelve el número de elementos en la bicola.
        
        Returns:
            int: Cantidad de elementos
        """
        return len(self.items)


class CircularQueue:
    """
    Implementación de una Cola Circular con capacidad fija.
    
    Attributes:
        capacity (int): Capacidad máxima de la cola
        data (list): Arreglo para almacenar los elementos
        size (int): Número actual de elementos en la cola
        front (int): Índice del elemento frontal
        rear (int): Índice del último elemento
    """
    
    def __init__(self, capacity):
        """
        Constructor para la cola circular.
        
        Args:
            capacity (int): Capacidad máxima de la cola
        """
        self.capacity = capacity
        self.data = [None] * capacity
        self.size = 0
        self.front = 0
        self.rear = -1
        
    def enqueue(self, value):
        """
        Agrega un elemento al final de la cola.
        
        Args:
            value: Elemento a agregar
            
        Raises:
            Exception: Si la cola está llena
        """
        if self.size == self.capacity:
            raise Exception("La cola circular está llena")
        
        self.rear = (self.rear + 1) % self.capacity
        self.data[self.rear] = value
        self.size += 1
        
    def dequeue(self):
        """
        Elimina y devuelve el elemento al frente de la cola.
        
        Returns:
            El elemento al frente
            
        Raises:
            Exception: Si la cola está vacía
        """
        if self.is_empty():
            raise Exception("La cola circular está vacía")
        
        value = self.data[self.front]
        self.data[self.front] = None
        self.front = (self.front + 1) % self.capacity
        self.size -= 1
        return value
    
    def is_empty(self):
        """
        Verifica si la cola está vacía.
        
        Returns:
            bool: True si está vacía, False en caso contrario
        """
        return self.size == 0
    
    def __len__(self):
        """
        Devuelve el número de elementos en la cola.
        
        Returns:
            int: Cantidad de elementos
        """
        return self.size


#----- PARTE 3: ALGORITMOS DE ORDENAMIENTO -----#

def merge_sort(lst):
    """
    Implementación del algoritmo de ordenamiento Merge Sort.
    
    Args:
        lst (list): Lista a ordenar
        
    Returns:
        list: Lista ordenada
    """
    if len(lst) <= 1:
        return lst
    
    # Dividir la lista en dos mitades
    mid = len(lst) // 2
    left = merge_sort(lst[:mid])
    right = merge_sort(lst[mid:])
    
    # Mezclar las dos mitades ordenadas
    return merge(left, right)

def merge(left, right):
    """
    Función auxiliar para mezclar dos listas ordenadas.
    
    Args:
        left (list): Primera lista ordenada
        right (list): Segunda lista ordenada
        
    Returns:
        list: Lista mezclada y ordenada
    """
    result = []
    i = j = 0
    
    # Mezclar ambas listas
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    
    # Agregar elementos restantes
    result.extend(left[i:])
    result.extend(right[j:])
    
    return result


def quick_sort(lst, low=None, high=None):
    """
    Implementación del algoritmo de ordenamiento Quick Sort.
    
    Args:
        lst (list): Lista a ordenar
        low (int): Índice de inicio
        high (int): Índice final
        
    Returns:
        list: La misma lista, ahora ordenada
    """
    # Inicializar valores por defecto
    if low is None:
        low = 0
    if high is None:
        high = len(lst) - 1
    
    if low < high:
        # Encontrar el pivote y hacer partición
        pivot_idx = partition(lst, low, high)
        
        # Ordenar recursivamente las sub-listas
        quick_sort(lst, low, pivot_idx - 1)
        quick_sort(lst, pivot_idx + 1, high)
    
    return lst

def partition(lst, low, high):
    """
    Función auxiliar para la partición en Quick Sort.
    
    Args:
        lst (list): Lista a particionar
        low (int): Índice de inicio
        high (int): Índice final
        
    Returns:
        int: Índice del pivote después de la partición
    """
    # Seleccionar el pivote (último elemento)
    pivot = lst[high]
    i = low - 1
    
    # Recorrer todos los elementos
    for j in range(low, high):
        # Si el elemento actual es menor o igual al pivote
        if lst[j] <= pivot:
            i += 1
            lst[i], lst[j] = lst[j], lst[i]
    
    # Colocar el pivote en su posición final
    lst[i + 1], lst[high] = lst[high], lst[i + 1]
    
    return i + 1


#----- PARTE 4: ALGORITMOS DE BÚSQUEDA -----#

def linear_search(lst, target):
    """
    Implementación de búsqueda lineal.
    
    Args:
        lst (list): Lista donde buscar
        target: Elemento a buscar
        
    Returns:
        int: Índice del elemento si se encuentra, -1 en caso contrario
    """
    for i in range(len(lst)):
        if lst[i] == target:
            return i
    return -1


def binary_search(lst, target):
    """
    Implementación de búsqueda binaria (requiere lista ordenada).
    
    Args:
        lst (list): Lista ordenada donde buscar
        target: Elemento a buscar
        
    Returns:
        int: Índice del elemento si se encuentra, -1 en caso contrario
    """
    low = 0
    high = len(lst) - 1
    
    while low <= high:
        mid = (low + high) // 2
        
        if lst[mid] == target:
            return mid
        elif lst[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return -1


#----- PARTE 5: ÁRBOL BINARIO DE BÚSQUEDA -----#

class BinaryTreeNode:
    """
    Nodo para un Árbol Binario.
    
    Attributes:
        value: Valor almacenado en el nodo
        left (BinaryTreeNode): Hijo izquierdo
        right (BinaryTreeNode): Hijo derecho
    """
    
    def __init__(self, value):
        """
        Constructor para un nodo de árbol binario.
        
        Args:
            value: Valor a almacenar en el nodo
        """
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    """
    Implementación de un Árbol Binario de Búsqueda.
    
    Attributes:
        root (BinaryTreeNode): Nodo raíz del árbol
    """
    
    def __init__(self):
        """Constructor para el árbol binario de búsqueda."""
        self.root = None
    
    def insert(self, value):
        """
        Inserta un valor en el árbol manteniendo la propiedad de BST.
        
        Args:
            value: Valor a insertar
        """
        if self.root is None:
            self.root = BinaryTreeNode(value)
        else:
            self._insert_recursive(self.root, value)
    
    def _insert_recursive(self, node, value):
        """
        Función auxiliar para insertar recursivamente.
        
        Args:
            node (BinaryTreeNode): Nodo actual
            value: Valor a insertar
        """
        if value < node.value:
            if node.left is None:
                node.left = BinaryTreeNode(value)
            else:
                self._insert_recursive(node.left, value)
        else:
            if node.right is None:
                node.right = BinaryTreeNode(value)
            else:
                self._insert_recursive(node.right, value)
    
    def find(self, value):
        """
        Busca un valor en el árbol.
        
        Args:
            value: Valor a buscar
            
        Returns:
            bool: True si se encuentra, False en caso contrario
        """
        return self._find_recursive(self.root, value)
    
    def _find_recursive(self, node, value):
        """
        Función auxiliar para buscar recursivamente.
        
        Args:
            node (BinaryTreeNode): Nodo actual
            value: Valor a buscar
            
        Returns:
            bool: True si se encuentra, False en caso contrario
        """
        if node is None:
            return False
        
        if node.value == value:
            return True
        elif value < node.value:
            return self._find_recursive(node.left, value)
        else:
            return self._find_recursive(node.right, value)
    
    def in_order_traversal(self):
        """
        Realiza un recorrido in-order del árbol.
        
        Returns:
            list: Lista con los valores en orden ascendente
        """
        result = []
        self._in_order_recursive(self.root, result)
        return result
    
    def _in_order_recursive(self, node, result):
        """
        Función auxiliar para recorrer recursivamente in-order.
        
        Args:
            node (BinaryTreeNode): Nodo actual
            result (list): Lista para almacenar los valores
        """
        if node:
            self._in_order_recursive(node.left, result)
            result.append(node.value)
            self._in_order_recursive(node.right, result)
    
    def height(self):
        """
        Calcula la altura del árbol.
        
        Returns:
            int: Altura del árbol (-1 si está vacío)
        """
        return self._height_recursive(self.root)
    
    def _height_recursive(self, node):
        """
        Función auxiliar para calcular la altura recursivamente.
        
        Args:
            node (BinaryTreeNode): Nodo actual
            
        Returns:
            int: Altura del subárbol
        """
        if node is None:
            return -1
        
        left_height = self._height_recursive(node.left)
        right_height = self._height_recursive(node.right)
        
        return max(left_height, right_height) + 1

